// Local Web App Logic (Demonstrates LocalStorage, File Chooser, DOM Events & JS APIs)

document.addEventListener("DOMContentLoaded", () => {
    loadNotes();
    setupImagePicker();
    setupCounter();
});

// 1. LocalStorage Note Keeper
function loadNotes() {
    const list = document.getElementById("todoList");
    list.innerHTML = "";
    const saved = JSON.parse(localStorage.getItem("offline_notes") || "[]");
    
    if (saved.length === 0) {
        list.innerHTML = '<li style="color:#64748b; font-size:0.8rem; text-align:center;">هیچ یادداشتی ذخیره نشده است.</li>';
        return;
    }

    saved.forEach((note, index) => {
        const li = document.createElement("li");
        li.className = "todo-item";
        li.innerHTML = `
            <span>${escapeHtml(note)}</span>
            <button onclick="deleteNote(${index})">حذف</button>
        `;
        list.appendChild(li);
    });
}

function addNote() {
    const input = document.getElementById("noteInput");
    const text = input.value.trim();
    if (!text) return;

    const saved = JSON.parse(localStorage.getItem("offline_notes") || "[]");
    saved.unshift(text);
    localStorage.setItem("offline_notes", JSON.stringify(saved));
    input.value = "";
    loadNotes();
}

function deleteNote(index) {
    const saved = JSON.parse(localStorage.getItem("offline_notes") || "[]");
    saved.splice(index, 1);
    localStorage.setItem("offline_notes", JSON.stringify(saved));
    loadNotes();
}

// 2. File Chooser / Image Upload via WebChromeClient
function setupImagePicker() {
    const uploadBox = document.getElementById("fileUploadBox");
    const fileInput = document.getElementById("fileInput");
    const preview = document.getElementById("imagePreview");
    const fileInfo = document.getElementById("fileInfo");

    uploadBox.addEventListener("click", () => {
        fileInput.click();
    });

    fileInput.addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
            fileInfo.textContent = `فایل انتخاب شده: ${file.name} (${Math.round(file.size / 1024)} KB)`;
            
            if (file.type.startsWith("image/")) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    preview.src = event.target.result;
                    preview.style.display = "block";
                };
                reader.readAsDataURL(file);
            } else {
                preview.style.display = "none";
            }
        }
    });
}

// 3. Counter test
let count = 0;
function setupCounter() {
    const counterDisplay = document.getElementById("counterDisplay");
    const btnInc = document.getElementById("btnInc");
    const btnDec = document.getElementById("btnDec");

    if (btnInc && btnDec && counterDisplay) {
        btnInc.addEventListener("click", () => {
            count++;
            counterDisplay.textContent = count;
        });
        btnDec.addEventListener("click", () => {
            count--;
            counterDisplay.textContent = count;
        });
    }
}

// Helper: Escape HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}
