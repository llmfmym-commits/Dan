package com.example.data.model

data class WebTab(
    val id: String,
    val title: String,
    val url: String,
    val iconPreset: String? = null
)
