package com.example.ui.launcher

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AppFolder
import com.example.data.model.WebAppItem
import com.example.util.FileUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditAppDialog(
    appItem: WebAppItem,
    folders: List<AppFolder>,
    totalPages: Int,
    onDismiss: () -> Unit,
    onSave: (WebAppItem) -> Unit,
    onDelete: (WebAppItem) -> Unit,
    onClearData: (WebAppItem) -> Unit = {}
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf(appItem.name) }
    var targetUrl by remember { mutableStateOf(appItem.targetUrl) }
    var iconPath by remember { mutableStateOf(appItem.iconPath) }
    var selectedPage by remember { mutableIntStateOf(appItem.pageIndex) }
    var selectedFolderId by remember { mutableStateOf(appItem.folderId) }
    var isLocked by remember { mutableStateOf(appItem.isLocked) }
    var isHidden by remember { mutableStateOf(appItem.isHidden) }

    // WebView Settings
    var jsEnabled by remember { mutableStateOf(appItem.javascriptEnabled) }
    var zoomEnabled by remember { mutableStateOf(appItem.zoomEnabled) }
    var desktopMode by remember { mutableStateOf(appItem.desktopMode) }
    var cookiesEnabled by remember { mutableStateOf(appItem.cookiesEnabled) }
    var isIncognito by remember { mutableStateOf(appItem.isIncognito) }
    var fullScreen by remember { mutableStateOf(appItem.fullScreen) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val savedPath = FileUtils.saveIconFromUri(context, uri)
            iconPath = savedPath
        }
    }

    var folderDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("مدیریت برنامه", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام برنامه") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // URL (if Web URL)
                if (appItem.type == "WEB_URL") {
                    OutlinedTextField(
                        value = targetUrl,
                        onValueChange = { targetUrl = it },
                        label = { Text("آدرس سایت (URL)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                // Logo
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF3B82F6)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (iconPath != null) {
                                AsyncImage(
                                    model = iconPath,
                                    contentDescription = "Logo",
                                    modifier = Modifier.size(48.dp),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = name.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("لوگوی فعلی", fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    ) {
                        Text("تغییر لوگو", fontSize = 12.sp)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Organization: Page and Folder
                Text("موقعیت و دسته‌بندی:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                
                // Page selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("انتقال به صفحه:", fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (p in 0 until maxOf(totalPages, selectedPage + 1)) {
                            val isCurrent = selectedPage == p
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isCurrent) Color(0xFF3B82F6) else Color(0xFF334155))
                                    .clickable { selectedPage = p },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${p + 1}", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Folder dropdown
                ExposedDropdownMenuBox(
                    expanded = folderDropdownExpanded,
                    onExpandedChange = { folderDropdownExpanded = !folderDropdownExpanded }
                ) {
                    val currentFolderName = folders.find { it.id == selectedFolderId }?.name ?: "بدون پوشه (صفحه اصلی)"
                    OutlinedTextField(
                        value = currentFolderName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("پوشه (Folder)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = folderDropdownExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = folderDropdownExpanded,
                        onDismissRequest = { folderDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("بدون پوشه (صفحه اصلی)") },
                            onClick = {
                                selectedFolderId = null
                                folderDropdownExpanded = false
                            }
                        )
                        folders.forEach { f ->
                            DropdownMenuItem(
                                text = { Text(f.name) },
                                onClick = {
                                    selectedFolderId = f.id
                                    folderDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Security & Visibility
                Text("امنیت و نمایش:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("قفل برنامه با رمز (PIN Lock)", fontSize = 13.sp)
                    Switch(checked = isLocked, onCheckedChange = { isLocked = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("مخفی کردن از صفحه اصلی (Hide)", fontSize = 13.sp)
                    Switch(checked = isHidden, onCheckedChange = { isHidden = it })
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // WebView Settings
                Text("تنظیمات WebView:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("JavaScript", fontSize = 13.sp)
                    Switch(checked = jsEnabled, onCheckedChange = { jsEnabled = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("زوم و بزرگ‌نمایی (Zoom)", fontSize = 13.sp)
                    Switch(checked = zoomEnabled, onCheckedChange = { zoomEnabled = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالت دسکتاپ (Desktop Mode)", fontSize = 13.sp)
                    Switch(checked = desktopMode, onCheckedChange = { desktopMode = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالت ناشناس (Incognito)", fontSize = 13.sp)
                    Switch(checked = isIncognito, onCheckedChange = { isIncognito = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تمام صفحه (Full Screen)", fontSize = 13.sp)
                    Switch(checked = fullScreen, onCheckedChange = { fullScreen = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = appItem.copy(
                        name = name.trim(),
                        targetUrl = targetUrl.trim(),
                        iconPath = iconPath,
                        pageIndex = selectedPage,
                        folderId = selectedFolderId,
                        isLocked = isLocked,
                        isHidden = isHidden,
                        javascriptEnabled = jsEnabled,
                        zoomEnabled = zoomEnabled,
                        desktopMode = desktopMode,
                        cookiesEnabled = cookiesEnabled,
                        isIncognito = isIncognito,
                        fullScreen = fullScreen
                    )
                    onSave(updated)
                    onDismiss()
                }
            ) {
                Text("ذخیره تغییرات")
            }
        },
        dismissButton = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = {
                            onClearData(appItem)
                            Toast.makeText(context, "داده‌های این برنامه پاک‌سازی شد", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFF59E0B))
                    ) {
                        Text("پاک‌سازی داده‌ها", fontSize = 12.sp)
                    }
                    Row {
                        TextButton(
                            onClick = {
                                onDelete(appItem)
                                onDismiss()
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF4444))
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حذف", fontSize = 12.sp)
                        }
                        TextButton(onClick = onDismiss) {
                            Text("انصراف", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    )
}
