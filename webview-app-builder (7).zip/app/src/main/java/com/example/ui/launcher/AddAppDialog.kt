package com.example.ui.launcher

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.WebAppItem
import com.example.util.FileUtils
import java.io.File
import java.util.UUID

@Composable
fun AddAppDialog(
    onDismiss: () -> Unit,
    onCreateApp: (name: String, type: String, targetUrl: String, iconPath: String?, iconPreset: String?) -> Unit,
    onPreviewApp: (WebAppItem) -> Unit
) {
    val context = LocalContext.current

    var selectedType by remember { mutableStateOf("WEB_URL") } // "WEB_URL", "HTML", "ZIP_PROJECT"
    var name by remember { mutableStateOf("") }
    var urlInput by remember { mutableStateOf("https://") }
    var rawHtmlInput by remember { mutableStateOf("<h1>Hello World</h1><p>My HTML app</p>") }
    var selectedZipUri by remember { mutableStateOf<Uri?>(null) }
    var zipFileName by remember { mutableStateOf("") }
    var iconPath by remember { mutableStateOf<String?>(null) }
    var iconPresetColor by remember { mutableStateOf("#3B82F6") }

    // Photo picker for custom logo
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val savedPath = FileUtils.saveIconFromUri(context, uri)
            iconPath = savedPath
        }
    }

    // File picker for ZIP project
    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedZipUri = uri
            zipFileName = uri.lastPathSegment ?: "project.zip"
        }
    }

    // File picker for single HTML file
    val htmlFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val tempId = UUID.randomUUID().toString()
            val savedPath = FileUtils.saveSingleHtmlFile(context, tempId, uri)
            if (savedPath != null) {
                rawHtmlInput = File(savedPath).readText()
                Toast.makeText(context, "فایل HTML بارگذاری شد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("ساخت برنامه جدید", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Type selector chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedType == "WEB_URL",
                        onClick = { selectedType = "WEB_URL" },
                        label = { Text("Web URL", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    FilterChip(
                        selected = selectedType == "HTML",
                        onClick = { selectedType = "HTML" },
                        label = { Text("HTML", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    FilterChip(
                        selected = selectedType == "ZIP_PROJECT",
                        onClick = { selectedType = "ZIP_PROJECT" },
                        label = { Text("ZIP Project", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                // Name field
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام برنامه (App Name)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Logo selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(android.graphics.Color.parseColor(iconPresetColor)))
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (iconPath != null) {
                                AsyncImage(
                                    model = iconPath,
                                    contentDescription = "App Logo",
                                    modifier = Modifier.size(50.dp),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = if (name.isNotBlank()) name.take(1).uppercase() else "★",
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("لوگوی برنامه", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(
                                text = if (iconPath != null) "تصویر انتخاب شده" else "پیش‌فرض خودکار",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("انتخاب لوگو", fontSize = 12.sp)
                    }
                }

                // Input based on selected type
                when (selectedType) {
                    "WEB_URL" -> {
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            label = { Text("آدرس وب‌سایت (URL)") },
                            placeholder = { Text("https://example.com") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                    "HTML" -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("کد HTML:", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                            TextButton(onClick = { htmlFilePickerLauncher.launch(arrayOf("text/html")) }) {
                                Text("انتخاب فایل HTML", fontSize = 12.sp)
                            }
                        }
                        OutlinedTextField(
                            value = rawHtmlInput,
                            onValueChange = { rawHtmlInput = it },
                            label = { Text("محتوای HTML") },
                            modifier = Modifier.fillMaxWidth().height(140.dp),
                            maxLines = 8
                        )
                    }
                    "ZIP_PROJECT" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFF64748B), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = null,
                                modifier = Modifier.size(40.dp),
                                tint = Color(0xFF3B82F6)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (selectedZipUri != null) zipFileName else "فایل ZIP پروژه وب را انتخاب کنید",
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "شامل index.html و استایل‌ها",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { zipPickerLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed")) }
                            ) {
                                Text("انتخاب ZIP")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        Toast.makeText(context, "لطفاً نام برنامه را وارد کنید", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    when (selectedType) {
                        "WEB_URL" -> {
                            var cleanUrl = urlInput.trim()
                            if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                                cleanUrl = "https://$cleanUrl"
                            }
                            onCreateApp(name.trim(), "WEB_URL", cleanUrl, iconPath, iconPresetColor)
                            onDismiss()
                        }
                        "HTML" -> {
                            val appId = UUID.randomUUID().toString()
                            val htmlPath = FileUtils.saveHtmlProject(context, appId, rawHtmlInput)
                            onCreateApp(name.trim(), "HTML", htmlPath, iconPath, iconPresetColor)
                            onDismiss()
                        }
                        "ZIP_PROJECT" -> {
                            val uri = selectedZipUri
                            if (uri == null) {
                                Toast.makeText(context, "لطفاً فایل ZIP را انتخاب کنید", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val appId = UUID.randomUUID().toString()
                            val indexPath = FileUtils.extractZipProject(context, appId, uri)
                            if (indexPath == null) {
                                Toast.makeText(context, "خطا: فایل index.html در پروژه ZIP یافت نشد!", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            onCreateApp(name.trim(), "ZIP_PROJECT", indexPath, iconPath, iconPresetColor)
                            onDismiss()
                        }
                    }
                }
            ) {
                Text("ساخت برنامه")
            }
        },
        dismissButton = {
            Row {
                // Live preview button
                TextButton(
                    onClick = {
                        val testName = if (name.isNotBlank()) name else "Preview"
                        when (selectedType) {
                            "WEB_URL" -> {
                                var cleanUrl = urlInput.trim()
                                if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                                    cleanUrl = "https://$cleanUrl"
                                }
                                onPreviewApp(
                                    WebAppItem(name = testName, type = "WEB_URL", targetUrl = cleanUrl)
                                )
                            }
                            "HTML" -> {
                                val tempPath = FileUtils.saveHtmlProject(context, "temp_preview", rawHtmlInput)
                                onPreviewApp(
                                    WebAppItem(name = testName, type = "HTML", targetUrl = tempPath)
                                )
                            }
                            "ZIP_PROJECT" -> {
                                val uri = selectedZipUri
                                if (uri != null) {
                                    val tempPath = FileUtils.extractZipProject(context, "temp_zip_preview", uri)
                                    if (tempPath != null) {
                                        onPreviewApp(
                                            WebAppItem(name = testName, type = "ZIP_PROJECT", targetUrl = tempPath)
                                        )
                                    } else {
                                        Toast.makeText(context, "فایل index.html یافت نشد", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(context, "لطفاً فایل ZIP انتخاب کنید", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("پیش‌نمایش")
                }

                TextButton(onClick = onDismiss) {
                    Text("انصراف")
                }
            }
        }
    )
}
